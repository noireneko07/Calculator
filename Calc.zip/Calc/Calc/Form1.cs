﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Linq;
using Calc.Database;

namespace Calc
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public string xmlPath = Properties.Settings.Default.XMLDirectory;
        public string textValue = "";
        public string memoryValue = "0";
        public string lastValue = "";
        public bool fromMemory = false;
        public string wTodo = "";
        public string logAction = "Add";
        public string logValues = "";
        public int logID = 1;

        DataTable DataTable = new DataTable();

        public List<string> memoryList = new List<string>();

        private void Form1_Load(object sender, EventArgs e)
        {
            textValue = "0";
            txtValue.Text = "0";
            
        }

        private void btnOne_Click(object sender, EventArgs e)
        {
            string value = "1";
            ConcatTextValues(value);
        }

        private void btnTwo_Click(object sender, EventArgs e)
        {
            string value = "2";
            ConcatTextValues(value);
        }

        private void btnThree_Click(object sender, EventArgs e)
        {
            string value = "3";
            ConcatTextValues(value);
        }

        private void btnFour_Click(object sender, EventArgs e)
        {
            string value = "4";
            ConcatTextValues(value);
        }

        private void btnFive_Click(object sender, EventArgs e)
        {
            string value = "5";
            ConcatTextValues(value);
        }

        private void btnSix_Click(object sender, EventArgs e)
        {
            string value = "6";
            ConcatTextValues(value);
        }

        private void btnSeven_Click(object sender, EventArgs e)
        {
            string value = "7";
            ConcatTextValues(value);
        }

        private void btnEight_Click(object sender, EventArgs e)
        {
            string value = "8";
            ConcatTextValues(value);
        }

        private void btnNine_Click(object sender, EventArgs e)
        {
            string value = "9";
            ConcatTextValues(value);
        }

        private void btnZero_Click(object sender, EventArgs e)
        {
            string value = "0";
            ConcatTextValues(value);

        }

        private void btnDecimal_Click(object sender, EventArgs e)
        {
            string value = ".";
            //check if txtvalue has decimal point
            if (!textValue.Contains("."))
            {
                ConcatTextValues(value);
            }

        }

        private void btnPosNeg_Click(object sender, EventArgs e)
        {
            string value = "-";
            if (!textValue.Contains("-"))
            {
                textValue = string.Concat(value, textValue);
            }
            else
            {
                textValue = textValue.Replace("-", "");
            }
            txtValue.Text = textValue;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            textValue = "0";
            lastValue = "";
            logValues = "0";
            logAction = "Clear";
            LogHistory(logAction);
            txtValue.Text = textValue;
            //reset to Add
            logAction = "Add";
        }


        private void ConcatTextValues(string newValue)
        {
            //check if last action was equals
            if (logAction == "Equal")
            {
                //reset values
                textValue = "0";
                logAction = "Add";
            }

            //check if value is from memory
            if (fromMemory)
            {
                //reset values
                textValue = "0";
                logAction = "Add";
                fromMemory = false;
            }

            if (newValue == ".")
            {
                textValue = string.Concat(textValue, newValue);
            }
            else
            {
                //check if inital value is 0
                if (textValue == "0")
                    textValue = "";

                textValue = string.Concat(textValue, newValue);
            }
         
            txtValue.Text = textValue;

        }

        private void btnMemClear_Click(object sender, EventArgs e)
        {
            memoryValue = "0";
            memoryList.Clear();
            lstMemory.Items.Clear();
            btnMemClear.Enabled = false;
            btnMemRecall.Enabled = false;
        }

        private void btnMemRecall_Click(object sender, EventArgs e)
        {
            fromMemory = true;
            textValue = memoryValue;
            txtValue.Text = memoryValue;
            btnMemClear.Enabled = false;
            btnMemRecall.Enabled = false;

        }

        private void btnMemPlus_Click(object sender, EventArgs e)
        {
            decimal value;
            if(decimal.TryParse(textValue,out value))
            {
                memoryValue = (decimal.Parse(memoryValue) + value).ToString();
                LoadMemory(memoryValue);
                textValue = "0";
                btnMemClear.Enabled = true;
                btnMemRecall.Enabled = true;
            }
        }

        private void btnMemNeg_Click(object sender, EventArgs e)
        {
            decimal value;
            if (decimal.TryParse(textValue, out value))
            {
                memoryValue = (decimal.Parse(memoryValue) - value).ToString();
                LoadMemory(memoryValue);
                textValue = "0";
                btnMemClear.Enabled = true;
                btnMemRecall.Enabled = true;
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string process = comboBox1.Text;
            decimal firstValue;
            decimal secondvalue;

            decimal.TryParse(lastValue, out firstValue);
            decimal.TryParse(textValue, out secondvalue);

         


            switch (wTodo)
            {
                case "+":
                    {
                        logValues = textValue;
                        textValue = (firstValue + secondvalue).ToString();
                        txtValue.Text = textValue;
                        wTodo = process;
                        lastValue = textValue;
                        textValue = "";
                        logAction = "Add";
                      
                        break;
                    }
                case "-":
                    {
                        logValues = textValue;
                        textValue = (firstValue - secondvalue).ToString();
                        txtValue.Text = textValue;
                        wTodo = process;
                        lastValue = textValue;
                        textValue = "";
                        logAction = "Subtract";
                       // logValues = lastValue;
                        break;
                    }
                case "x":
                    {
                        logValues = textValue;
                        textValue = (firstValue * secondvalue).ToString();
                        txtValue.Text = textValue;
                        wTodo = process;
                        lastValue = textValue;
                        textValue = "";
                        logAction = "Multiply";
                       // logValues = lastValue;
                        break;
                    }
                case "/":
                    {
                        try
                        {
                            logValues = textValue;
                            textValue = (firstValue / secondvalue).ToString();
                            txtValue.Text = textValue;
                            wTodo = process;
                            lastValue = textValue;
                            textValue = "";
                            logAction = "Divide";
                           // logValues = lastValue;
                        }
                        catch
                        {
                            textValue = "";
                            logValues = "Error!";
                        }
                     
                        break;
                    }
                default:
                    {
                        lastValue = textValue;
                        textValue = "";
                        wTodo = process;
                        txtValue.Text = lastValue;
                        logAction = "Add";
                        logValues = lastValue;
                        break;
                    }
            }
            LogHistory(logAction);


        }

        private void btnEquals_Click(object sender, EventArgs e)
        {
            
            decimal firstValue;
            decimal secondvalue;

            decimal.TryParse(lastValue, out firstValue);
            decimal.TryParse(textValue, out secondvalue);
            logValues = textValue;
     
            switch (wTodo)
            {
                case "+":
                    {
                        logAction = "Add";
                        LogHistory(logAction);
                        textValue = (firstValue + secondvalue).ToString();
                        txtValue.Text = textValue;
                        lastValue = "";
                        logValues = textValue;
                        break;
                    }
                case "-":
                    {

                        logAction = "Subtract";
                        LogHistory(logAction);

                        textValue = (firstValue - secondvalue).ToString();
                        txtValue.Text = textValue;
                        lastValue = "";
                        logValues = textValue;
                        break;
                    }
                case "x":
                    {

                        logAction = "Multiply";
                        LogHistory(logAction);
                        textValue = (firstValue * secondvalue).ToString();
                        txtValue.Text = textValue;
                        lastValue = "";
                        logValues = textValue;
                        break;
                    }
                case "/":
                    {
                        try
                        {

                            logAction = "Divide";
                            LogHistory(logAction);
                            textValue = (firstValue / secondvalue).ToString();
                            txtValue.Text = textValue;
                            lastValue = "";
                            logValues = textValue;
                        }
                        catch
                        {
                            txtValue.Text = "Error!";
                           logValues = "Error!";
                        }

                        break;
                    }
                default:
                    {
                        txtValue.Text = textValue;
                        break;
                    }
            }


            logAction = "Equal";
            LogHistory(logAction);

            wTodo = "";


        }

      
        private void LogHistory(string item)
        {
            //DB access
            //CalcLogsEntities calcLogsEntities = new CalcLogsEntities();

            //History h = new History();
            //h.Hist_Action = item;
            //h.Hist_Value = logValues;

            //calcLogsEntities.Histories.Add(h);
            //calcLogsEntities.SaveChanges();
            SaveToXML(item);
        }

        private void LoadMemory(string memValue)
        {
            memoryList.Add(memoryValue);
            lstMemory.Items.Add(memoryList.Last());
        }

        private void copyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(txtValue.Text);
        }

        private void pasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string fromClipboard = Clipboard.GetText();

            if (decimal.TryParse(fromClipboard, out decimal res))
                txtValue.Text = Clipboard.GetText();
            else
                MessageBox.Show("Text not valid!");
        }


        private void SaveToXML(string item)
        {

            if (!File.Exists(xmlPath))
            {

                using (XmlWriter writer = XmlWriter.Create(xmlPath))
                {
                    writer.WriteStartElement("Histories");
                    writer.WriteStartElement("History");
                    writer.WriteElementString("Hist_ID", logID.ToString());
                    writer.WriteElementString("Hist_Action", item);
                    writer.WriteElementString("Hist_Value", logValues);
                    writer.WriteEndElement();
                    writer.WriteEndElement();
                    writer.Flush();
                }

            }
            else
            {
                //check last item for hist id

                XDocument xml = XDocument.Load(xmlPath);
                var lastID = xml.Element("Histories").Elements("History").Select(x => x.Element("Hist_ID")).Last();

                if (int.TryParse(lastID.Value.ToString(), out int res))
                    logID = res + 1;

                XElement Histories = xml.Element("Histories");
                Histories.Add(new XElement("History",
                           new XElement("Hist_ID", logID.ToString()),
                           new XElement("Hist_Action", item),
                           new XElement("Hist_Value", logValues)
                           ));
                xml.Save(xmlPath);
            }
        }

        private void importFromFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            bool valid = true;
            DialogResult result = DialogResult.No;
            if (File.Exists(xmlPath))
               result = MessageBox.Show("This will overwrite the old History File, Continue?", "File Exists", MessageBoxButtons.YesNo);

            if (result == DialogResult.Yes)
            {
                OpenFileDialog openFile = new OpenFileDialog();
                openFile.Filter = "CSV |*.csv";
                openFile.ShowDialog();

                if (openFile.FileName != "")
                {

                    CreateXMLFile();
                    using (var csvStreamReader = new StreamReader(openFile.FileName))
                    {
                        int count = 0;
                        //load xmlFile here
                        XDocument xml = XDocument.Load(xmlPath);
                        while (!csvStreamReader.EndOfStream)
                        {
                            //check if file has 3 columns
                            var line = csvStreamReader.ReadLine();
                            var splitVal = line.Split(',');
                            if (count == 0)
                            {
                                //check first line if valid column header
                                if (splitVal[0] != "Hist_ID")
                                    valid = false;
                                if (splitVal[1] != "Hist_Action")
                                    valid = false;
                                if (splitVal[2] != "Hist_Value")
                                    valid = false;
                            }
                            else
                            {
                                //overwrite history file
                                XElement Histories = xml.Element("Histories");
                                Histories.Add(new XElement("History",
                                  new XElement("Hist_ID", splitVal[0].ToString()),
                                  new XElement("Hist_Action", splitVal[1].ToString()),
                                  new XElement("Hist_Value", splitVal[2].ToString())
                                  ));
                            }
                            count++;
                        }
                        xml.Save(xmlPath);
                    }

                }
            }

        }

        private void exportToFileToolStripMenuItem_Click(object sender, EventArgs e)
        {

            if (File.Exists(xmlPath))
            {
                SaveFileDialog saveFile = new SaveFileDialog();
                saveFile.Filter = "CSV |*.csv";
                saveFile.ShowDialog();

                if (saveFile.FileName != "")
                {

                    XDocument xml = XDocument.Load(xmlPath);
                    var history = xml.Root.Elements("History").Select(x => new
                    {
                        Hist_ID = x.Element("Hist_ID").Value,
                        Hist_Action = x.Element("Hist_Action").Value,
                        Hist_Value = x.Element("Hist_Value").Value
                    }).ToList();


                    using (var csvFileWriter = new StreamWriter(saveFile.FileName))
                    {
                        csvFileWriter.WriteLine("Hist_ID,Hist_Action,Hist_Value");
                        foreach (var h in history)
                        {
                            string csvLine = string.Format("{0},{1},{2}", h.Hist_ID, h.Hist_Action, h.Hist_Value);
                            csvFileWriter.WriteLine(csvLine);
                        }
                    }


                }
                
            }
            else
            {
                MessageBox.Show("No History File Found");
            }
        }

        private void CreateXMLFile()
        {
            using (XmlWriter writer = XmlWriter.Create(xmlPath))
            {
                writer.WriteStartElement("Histories");
                writer.WriteEndElement();
                writer.Flush();
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Exit", "Exit", MessageBoxButtons.YesNo) == DialogResult.Yes)
                this.Close();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
       
        }

        private void clearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textValue = "0";
            lastValue = "";
            logValues = "0";
            logAction = "Clear";
            LogHistory(logAction);
            txtValue.Text = textValue;
            //reset to Add
            logAction = "Add";
        }

        private void btnErase_Click(object sender, EventArgs e)
        {
            if (textValue.Length > 0)
            {
                textValue = textValue.Remove(textValue.Length - 1);
                txtValue.Text = textValue;
            }
            else
            {
                textValue = "0";
                txtValue.Text = textValue;
            }
        }
    }
}
